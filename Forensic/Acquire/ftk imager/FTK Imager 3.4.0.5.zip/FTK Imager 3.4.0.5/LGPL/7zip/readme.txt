Copyright (c) 2011 AccessData, Corp.

To conform with the 7-zip GNU LGPL license, the DA_7Z DLL wrapper code found
here is made available and is also licensed under the GNU LGPL.
